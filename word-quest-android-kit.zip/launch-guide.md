# Word Quest 安卓上架：一步步指南

整个流程分 6 个阶段。个人账号从注册到正式上架，大约要 3 周以上，主要时间花在 Google 要求的 14 天封闭测试上。

**费用：** Google Play 开发者账号 25 美元，一次性。

---

## 阶段 1：把网站搬到"根域名"（约 15 分钟）

**为什么要做这一步：** 安卓 app 要在网站根目录放一个验证文件（`.well-known/assetlinks.json`），app 才能全屏显示、不出现浏览器地址栏。GitHub 项目页（`用户名.github.io/wordquest/`）放不了根目录的文件，所以要新建一个名字特殊的仓库。

1. 登录 GitHub，点右上角 **+**，再点 **New repository**。
2. 仓库名必须填 **`fancybenben-commits.github.io`**（你的用户名加 `.github.io`），选 **Public**，点 **Create repository**。
3. 打开 `site` 文件夹里的 **privacy.html**，用记事本把 `[YOUR NAME]`、`[YOUR EMAIL]`、`[你的姓名]`、`[你的邮箱]` 换成你自己的信息。
4. 点 **uploading an existing file**，把 `site` 文件夹里的这几个文件拖进去：`index.html`、`manifest.json`、`sw.js`、`privacy.html`、`icon-192.png`、`icon-512.png`、`apple-touch-icon.png`。点 **Commit changes**。
5. 再建两个隐藏文件（网页上传不方便，用网页编辑器创建）：
   - 点 **Add file → Create new file**，文件名填 `.nojekyll`，内容随便输入一个字母，点 **Commit changes**。
   - 再点 **Add file → Create new file**，文件名填 `.well-known/assetlinks.json`（输入斜杠会自动变成文件夹），内容先粘贴 `site/.well-known/assetlinks.json` 里的模板，**先不用改**，点 **Commit changes**。
6. 打开 **Settings → Pages**，Branch 选 **main**，文件夹选 **/(root)**，点 **Save**。
7. 等 1 到 2 分钟，在浏览器打开 `https://fancybenben-commits.github.io/`，确认能玩游戏；再打开 `https://fancybenben-commits.github.io/privacy.html`，确认隐私政策能显示。

旧的 `wordquest` 仓库可以先保留，不影响新网址。

---

## 阶段 2：用 PWABuilder 生成安卓安装包（约 10 分钟）

1. 打开 **pwabuilder.com**，输入 `https://fancybenben-commits.github.io/`，点 **Start**。
2. 等它检测完，点 **Package for stores**，选 **Android**。
3. 在选项页填写：
   - Package ID：`io.github.fancybenbencommits.wordquest`（**上传后不能再改**）
   - App name：`Word Quest`
   - Short name：`Word Quest`
   - App version：`1.0.0`，Version code：`1`
   - Display mode：`Standalone`
   - Signing key：选 **New**（新建）
4. 点 **Generate** 并下载压缩包。里面有：
   - `.aab` 文件（要上传到 Google Play）
   - 一个 `.keystore` 签名文件，以及记录密码和指纹的文本文件
5. **把整个压缩包备份到至少两个地方**（比如电脑和网盘）。丢了签名文件和密码，以后就没法更新 app。

---

## 阶段 3：注册 Google Play 开发者账号（约 30 分钟，外加身份验证时间）

1. 打开 **play.google.com/console**，用你的 Google 账号登录。
2. 选择账号类型：
   - **个人账号：** 需要做 12 人 14 天的封闭测试（适用于 2023 年 11 月 13 日之后创建的账号）。
   - **组织账号：** 需要有注册公司，不需要封闭测试，但要做公司验证。
   - 没有公司的话，选个人账号。
3. 付 25 美元，并按提示完成身份验证（可能要拍证件）。
4. 等验证通过的通知邮件。

---

## 阶段 4：创建 app 并填写资料（约 1 到 2 小时）

1. 在后台点 **Create app**，名称填 `Word Quest: Vocab & Spelling`，语言选 English (United States)，类型选 **App**，价格选 **Free**，勾选声明后创建。
2. 在 **Grow → Store presence → Main store listing** 填商店信息，文案全部在 `store-listing.md` 里，图片在 `graphics` 文件夹里。
3. 在 **Policy and programs → App content** 里逐项完成（答案见 `store-listing.md` 第 5 节）：隐私政策、广告、应用访问权限、内容分级、目标受众、数据安全。
4. 如果想要中文商店页：Store presence 里点 **Manage translations** 添加简体中文，粘贴中文文案。

---

## 阶段 5：封闭测试（至少 14 天）

1. 在后台左侧找到 **Test and release → Testing → Closed testing**，点 **Create track**（或使用默认轨道）。
2. 点 **Create new release**，上传阶段 2 得到的 `.aab` 文件。
   - 如果后台问 Play App Signing，选择**使用 Google 管理签名**（默认选项）。
3. **更新验证文件（重要）：**
   1. 在后台 **Test and release → App integrity → App signing**，找到 **App signing key certificate** 的 **SHA-256 certificate fingerprint**，复制下来。
   2. 回到 GitHub，打开 `.well-known/assetlinks.json`，点铅笔图标，把 `PASTE_PLAY_APP_SIGNING_SHA256_HERE` 换成刚复制的指纹。
   3. 阶段 2 下载的文本文件里有 PWABuilder 签名文件的 SHA-256，用来替换 `PASTE_PWABUILDER_UPLOAD_KEY_SHA256_HERE`。
   4. 保存后，浏览器打开 `https://fancybenben-commits.github.io/.well-known/assetlinks.json`，确认能看到内容。
4. 在 **Testers** 标签里新建邮件列表，添加测试者的 Gmail 地址，保存后复制 **opt-in 链接**。
5. 用 `store-listing.md` 第 6 节的消息模板，把链接发给 15 到 20 个亲友。
6. 测试者必须：点链接加入、用同一个 Google 账号在手机上安装，并且**连续 14 天**保持安装。
7. 后台会显示进度。满足条件后，会出现 **Apply for production** 按钮。

**检查 app 是否正常：** 测试者打开 app 时，如果顶部出现浏览器地址栏，说明验证文件有问题，回头检查第 3 步里的指纹和包名是否一致。

---

## 阶段 6：申请正式发布

1. 满足 14 天后，点 **Apply for production**，回答几个关于测试情况的问题。
2. 审核通过后，进入 **Production**，创建新版本，选择同一个 `.aab`，点 **Send for review**。
3. 审核一般需要几天，新账号可能更久，请耐心等待。
4. 通过后，你的 app 会出现在 Google Play。

---

## 上架之后

- **更新单词和功能：** 不需要重新提交。把新的 `index.html` 上传到 GitHub，app 下次联网打开时就会自动更新。
- **只有这些情况才需要提交新版本：** 改图标、改应用名称、改包名，或者更换签名。
- **改了隐私相关的功能（比如加广告或统计）：** 一定要先更新隐私政策和 Data safety 问卷。
- **Android 开发者验证：** Google 正在逐步推出新的开发者身份验证要求。上架前请在 Play Console 里留意相关通知，按提示操作即可。

---

## 常见问题

**app 打开后顶部有地址栏怎么办？**
检查 `assetlinks.json` 是否能通过网址访问，里面的包名是否是 `io.github.fancybenbencommits.wordquest`，指纹是否和 Play Console 里的一致。

**测试者人数够了，但 14 天没算？**
测试者必须"已加入并安装"，只收到邀请不算。有人中途卸载，要补人。

**我想上苹果 App Store 怎么办？**
需要一台 Mac 和每年 99 美元的开发者账号，而且苹果对"网页套壳"审核更严格。建议先把安卓版上线，再决定是否做 iOS 版。

**我想改应用名称或图标？**
商店里的名称和图标可以在后台直接改。手机桌面上的图标需要重新打包并发布新版本才会变。
