# Word Quest – Google Play 商店资料（可直接复制粘贴）

使用时把方括号里的内容换成你自己的信息：`[你的邮箱]`、`[你的姓名]`。

---

## 1. 基本信息

| 项目 | 内容 |
|---|---|
| App 名称（≤30 字符） | `Word Quest: Vocab & Spelling`（28 字符） |
| 备选名称 | `Word Quest: Spelling Bee`（24 字符） |
| 包名（上传后不能改） | `io.github.fancybenbencommits.wordquest` |
| 应用类型 | 应用（App），免费 |
| 类别 | 教育（Education） |
| 标签 | Education, Vocabulary, Spelling |
| 联系邮箱 | [你的邮箱] |
| 隐私政策网址 | `https://fancybenben-commits.github.io/privacy.html` |
| 网站（可选） | `https://fancybenben-commits.github.io/` |

---

## 2. 英文（默认语言 en-US）

**Short description（≤80 字符）**

```
Daily vocabulary and spelling bee practice for kids, grades K–12.
```

**Full description（≤4000 字符）**

```
Word Quest turns vocabulary practice into a quick daily game. Learn a few new words each day, then review the older ones right when you are about to forget them. Pick your grade level and play.

HOW IT WORKS
• Daily Practice: 5 new words plus your review words, in a short session.
• Smart review: words you know well come back later, tricky words come back sooner.
• Build a streak: practice every day to keep your fire going and earn XP.

FOR EVERY GRADE
• K–2: everyday words like friend, rainbow, and whisper
• 3–5: words like adventure, familiar, and discover
• 6–8: words like hypothesis, reluctant, and persuade
• 9–12: challenge words like ubiquitous, camaraderie, and meticulous
Over 330 built-in words, each with a kid-friendly meaning and an example sentence.

SPELLING BEE MODE
Listen to the word, ask for the meaning or a sentence, then spell it. Fifteen rounds, words get longer, and one miss means you are out. How far can you go?

MORE WAYS TO PRACTICE
• Flashcards with pronunciation
• Meaning quiz with hearts and streak bonuses
• Fill-in-the-blank sentences
• Type-the-word spelling practice
• Add your own words, with optional dictionary lookup

SAFE AND SIMPLE
• No ads
• No sign-up or account
• No in-app purchases
• Your progress stays on your device
• Works offline after the first load

Great for homework help, test prep, classroom warm-ups, and spelling bee training.
```

**What’s new（版本 1.0.0）**

```
First release! Daily practice with spaced review, 4 grade levels (K–12), and Spelling Bee mode.
```

---

## 3. 简体中文（zh-CN，可选）

**应用名称：** `Word Quest：词汇与拼写`

**简短说明（≤80 字）**

```
每天学新词、复习旧词，K–12 英语词汇与拼写比赛练习。
```

**完整说明**

```
Word Quest 把背单词变成每天几分钟的小游戏。每天学几个新词，并在快要忘记的时候复习旧词。选好年级，马上开始。

玩法
• 每日练习：每天 5 个新词，加上需要复习的旧词，几分钟就能完成。
• 智能复习：掌握得好的词隔久一点再出现，容易错的词会更早回来。
• 连续打卡：每天练习，保持连续天数，赚取经验值。

适合每个年级
• K–2：friend、rainbow、whisper 等日常词汇
• 3–5：adventure、familiar、discover 等
• 6–8：hypothesis、reluctant、persuade 等
• 9–12：ubiquitous、camaraderie、meticulous 等挑战词
内置 330 多个单词，每个都有简明的英文释义和例句。

拼写比赛模式
先听单词，可以再听释义或例句，然后拼写。共 15 轮，单词越来越长，错一个就淘汰。你能走到第几轮？

更多练习方式
• 带发音的单词卡片
• 释义选择题（有爱心和连击奖励）
• 例句填空
• 听写式拼写练习
• 添加自己的单词，可选在线词典查询

安全简单
• 没有广告
• 不需要注册账号
• 没有内购
• 学习进度只保存在你的设备上
• 首次加载后可离线使用

适合作业辅助、考试准备、课堂热身和拼写比赛训练。
```

**新版本说明**

```
首次发布！支持每日练习与间隔复习、4 个年级段（K–12）和拼写比赛模式。
```

---

## 4. 图片素材（在 graphics 文件夹里）

| 位置 | 文件 | 规格 |
|---|---|---|
| 应用图标 | `graphics/icon-512.png` | 512×512 |
| 置顶大图 | `graphics/feature-graphic-1024x500.png` | 1024×500 |
| 手机截图 | `graphics/screenshots/phone-1.png` 到 `phone-6.png` | 1080×1920（9:16） |

截图顺序建议：1 首页，2 学新词，3 释义题，4 拼写，5 拼写比赛，6 完成页。

---

## 5. 后台表单答案（App content 部分）

**Privacy policy（隐私政策）**
填网址：`https://fancybenben-commits.github.io/privacy.html`

**Ads（广告）**
选 **No, my app does not contain ads**

**App access（应用访问权限）**
选 **All functionality is available without special access**（不需要登录）

**Content rating（内容分级）**
- 类别选 **Reference, news, or educational**
- 暴力、性内容、脏话、毒品、赌博：全部选 **No**
- 用户之间能否互动或分享内容：**No**
- 是否分享位置：**No**
- 是否有应用内购买：**No**
- 预期结果：适合所有年龄

**Target audience and content（目标受众）**
- 建议勾选：**5–8、9–12、13–15、16–17**（因为内容覆盖 K–12）
- 只要选了 13 岁以下年龄段，应用就会被当作面向儿童的应用，需要符合 Google Play 的 **Families Policy**。
- 你的 app 没有广告、没有账号、没有数据收集、没有第三方 SDK，这些都符合要求。
- 如果后台问是否"吸引儿童"，如实选 **Yes**。

**Data safety（数据安全）**
- Does your app collect or share any of the required user data types? → **No**
- 隐私政策链接：同上
- 说明：应用本身没有收集任何用户数据，进度只保存在设备本地。
- **重要（新增的词典查询功能）：** "Add my own words" 页面里的 "Look up meaning" 按钮，会在用户点击时把输入的那一个单词发送给第三方词典服务 dictionaryapi.dev。这不含个人信息，但 Google 对"收集/共享"的定义很严格，我无法确定它会被如何归类。请阅读问卷里每个选项的说明后再回答，拿不准时按"如实申报"处理。
- **想保持最简单的"不收集数据"声明？** 把 `index.html` 里的 `const ONLINE_LOOKUP=true;` 改成 `false`，在线查询按钮就会消失，用户仍然可以手动输入自己的单词。同时隐私政策里的"Optional dictionary lookup"那一段也可以删除。
- 提醒：这份问卷是你向 Google 的声明，请按你实际发布的版本如实填写。如果以后加了广告、统计工具或登录功能，必须回来修改。

**Government apps / Financial features / Health**
全部选 **No / None**

**News app**
选 **No**

---

## 6. 邀请 12 位测试者的消息模板

**中文**

```
你好！我做了一个给学生练英语单词和拼写的小 app，叫 Word Quest。Google 要求新应用上架前先找 12 个人连续测试 14 天，想请你帮个忙：

1. 点这个链接加入测试：[粘贴后台里的测试链接]
2. 用你的 Google 账号同意加入，然后在 Google Play 里安装
3. 14 天内保持安装，偶尔打开玩一玩就行（不需要每天）

只需要 1 分钟设置，非常感谢！
```

**English**

```
Hi! I made a small app for practicing vocabulary and spelling, called Word Quest. Google requires new apps to be tested by 12 people for 14 days before launch, and I would love your help:

1. Join the test with this link: [paste the opt-in link from Play Console]
2. Accept with your Google account, then install the app from Google Play
3. Keep it installed for 14 days and open it once in a while (no need to play every day)

It takes about a minute. Thank you so much!
```

提示：多邀请一些人（建议 15 到 20 个），因为中途有人退出或卸载，就会重新计算天数。
